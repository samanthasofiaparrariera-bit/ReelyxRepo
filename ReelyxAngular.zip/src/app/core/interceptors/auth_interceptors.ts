import {AuthCookieService} from "../services/cookies/auth-cookie.service";
import {inject} from "@angular/core";
import { HttpInterceptorFn } from '@angular/common/http';


export const authInterceptor: HttpInterceptorFn = (req, next) => {
  const cookieService = inject(AuthCookieService)
  const token = cookieService.get("reelyx_token")

  req = req.clone({
    setHeaders:{
      "Authorization": (token) ? `Bearer ${token}` : "REELYX",
      "Content-Type": "application/json",
    }
  })
  return next(req);
};
