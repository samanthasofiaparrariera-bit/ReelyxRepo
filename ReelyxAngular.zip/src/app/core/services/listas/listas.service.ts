import {Injectable} from '@angular/core';

@Injectable({
  providedIn: 'root',
})
export class ListasService {

  private KEY = 'lista_selection_id';
  private MAX = 30;


  private getIds(): string[] {
    const texto = sessionStorage.getItem(this.KEY);
    return texto ?  JSON.parse(texto):[]

  }
  private saveIds(ids: string[]) {
    sessionStorage.setItem(this.KEY, JSON.stringify(ids));
  }
  // revisa si esta en la lista o no
  seleccionado(id: string) {

    const ids = this.getIds();
    return ids.includes(id)

  }

  count() {
    return this.getIds().length;
  }

  reset(){
    this.saveIds([])
  }

  toggle(id: string) {
    const ids = this.getIds();

    // puse i porque me acorde del fori
    if (ids.includes(id)){
      const nuevos = ids.filter(i => i !== id);
      this.saveIds(nuevos);
      return
    }
    if (ids.length >= this.MAX) {
      alert('Máximo 30 pelis')
      return
    }
    ids.push(id)
    this.saveIds(ids)
  }

}
