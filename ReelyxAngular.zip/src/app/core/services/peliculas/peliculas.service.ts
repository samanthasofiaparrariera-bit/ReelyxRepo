import {Injectable, signal} from '@angular/core';

@Injectable({
  providedIn: 'root',
})
export class PeliculasService {

  // TODAS LAS PELIS

  pelis = signal([
    {id: '1', name:'Portrait of Time', imagen: 'moviestock3.jpg', duration:'3h', genre:'Drama',year:'2000',rating:'1'},
    {id: '2',name:'Totoro', imagen: 'moviestock9.jpg', duration:'2h', genre:'Sci-Fi',year:'1970',rating:'5'},
    {id: '3',name:'Doraemon', imagen: 'moviestock8.jpg', duration:'3h', genre:'Drama',year:'2020',rating:'4'},
    {id: '4',name:'Portrait of Time', imagen: 'moviestock3.jpg', duration:'2h', genre:'Romance',year:'2000',rating:'3'},
    {id: '5',name:'UP', imagen: 'moviestock3.jpg', duration:'3h', genre:'Romance',year:'1970',rating:'3'},
    {id: '6',name:'Portrait of Time', imagen: 'moviestock3.jpg', duration:'1h', genre:'Romance',year:'2000',rating:'3'},
    {id: '7',name:'Portrait of Time', imagen: 'moviestock3.jpg', duration:'1h', genre:'Sci-Fi',year:'2000',rating:'2'},
    {id: '8',name:'Portrait of Time', imagen: 'moviestock3.jpg', duration:'3h', genre:'Drama',year:'2020',rating:'1'},
    {id: '9',name:'Portrait of Time', imagen: 'moviestock3.jpg', duration:'1h', genre:'Romance',year:'1970',rating:'3'},
    {id: '10',name:'Portrait of Time', imagen: 'moviestock3.jpg', duration:'1h', genre:'Drama',year:'2000',rating:'4'},
    {id: '11',name:'Portrait of Time', imagen: 'moviestock3.jpg', duration:'2h', genre:'Romance',year:'1970',rating:'3'},
    {id: '12',name:'Portrait of Time', imagen: 'moviestock3.jpg', duration:'1h', genre:'Romance',year:'2020',rating:'5'},

  ]);
//   getters y setters
//   nombre(name:tipo){algo y su return}
  getFilm(){
    return this.pelis
  }

  getFilmId(id: string){
    const listaPelis = this.pelis();
    for (let i = 0; i < this.pelis().length; i++) {
      if (this.pelis()[i].id === id){
        return this.pelis()[i];
      }
    }
    return null;

  }

}
