import {AbstractControl, ValidationErrors} from "@angular/forms";

export function EmailValidator(control: AbstractControl): null | ValidationErrors {

  const value = control.value;

  if (!value) {
    return null;
  }

  const mailTipo = /@(gmail|hotmal|outlook) (\.)/i;

  if(!mailTipo.test(value)) {
    return {extension: true}
  }
  // basicamente le pido que el user tenga al menos 4 caracteres de lo que sea
  const wholeMail = /^[a-z0-9._%+-]{4,}(@)(gmail|hotmal|outlook)(\.)(com|es)$/;


  return wholeMail.test(value) ? null : {customEmail: true};

}



