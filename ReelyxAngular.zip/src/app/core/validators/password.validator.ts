import {AbstractControl, ValidationErrors} from "@angular/forms";


export function checkPassValidator(control: AbstractControl): ValidationErrors | null {

    const value: string = control.value;

    if (!value) {
        return null;
    }
    // le obligo a poner un caracter especial
    const pass = /^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)(?=.*[@$!%*?&])[A-Za-z\d@$!%*?&]{8,}$/;

    const validate = pass.test(value);

    return validate ? null : {customPassword: true};

}

