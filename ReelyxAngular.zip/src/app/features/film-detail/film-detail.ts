import {Component, OnInit, signal} from '@angular/core';
import {NgClass} from '@angular/common';
import {PeliculasService} from '../../core/services/peliculas/peliculas.service';
import {ActivatedRoute} from '@angular/router';

interface FilmInterface {
  id:string;
  name:string;
  imagen:string;
  duration:string;
  genre:string;
  year:string;
  rating:string;
}

@Component({
  selector: 'app-film-detail',
  imports: [

  ],
  templateUrl: './film-detail.html',
  styleUrl: './film-detail.scss',
})
// no se como arreglar esto ya ni se que quería hacer
export class FilmDetail implements OnInit {
  peli = signal<any>(null);

  constructor(private peliculasService : PeliculasService, private route: ActivatedRoute) {
  }

  ngOnInit() {
      const  id = this.route.snapshot.params['id'];
      if (id){
        const data = this.peliculasService.getFilmId(id)
        if (data){
          this.peli.set(data)
        }
      }
        throw new Error("Method not implemented.");
    }








}
