import {Component, signal} from '@angular/core';
import {NgClass} from '@angular/common';
import {PeliculasService} from '../../core/services/peliculas/peliculas.service';

@Component({
  selector: 'app-films',
  imports: [
    NgClass
  ],
  templateUrl: './films.html',
  styleUrl: './films.scss',
})
export class Films {
    pelis : any;

    constructor(private peliculasService : PeliculasService) {
      this.pelis = this.peliculasService.getFilm();
    }

    // FILTRO - DISPLAY
    dropdownOpen = signal<string>('');

    toggleMenu(name: string) {
      if (this.dropdownOpen() === name) {
        this.dropdownOpen.set('');
      }else {
        this.dropdownOpen.set(name);
      }
    }
  // FILTRO - APLICAR
  // reminder Actualizar datos pelis y hacer un signal
  //  signals con valor all para q se muestren todas
  // Hacemos todos los filtros y luego hacemos un set
    filterYear = signal<string>('all')
    filterGenre = signal<string>('all')
    filterDuration = signal<string>('all')
    filterRating = signal<string>('all')

    filterByYear(year: string){
      this.filterYear.set(year);
      this.dropdownOpen.set('');
    }

    filterByGenre(genre: string){
      this.filterGenre.set(genre);
      this.dropdownOpen.set('');
    }

    filterByDuration(duration: string){
      this.filterDuration.set(duration);
      this.dropdownOpen.set('');
    }

  filterByRating(rating: string){
    this.filterRating.set(rating);
    this.dropdownOpen.set('');
  }

  resetFilter() {
      this.filterDuration.set('all')
      this.filterRating.set('all')
      this.filterGenre.set('all')
      this.filterYear.set('all')
      this.searchFilm.set('')
  }


// BUSCAR PELI
//   empieza vacia para que se vea todo y luego recibe el signal en lowercase
    searchFilm = signal<string>('');

    searchBar( buscado:string){
      this.searchFilm.set(buscado);
    }

}
