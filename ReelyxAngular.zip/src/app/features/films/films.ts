import {Component, signal} from '@angular/core';
import {NgClass} from '@angular/common';
import {PeliculasService} from '../../core/services/peliculas/peliculas.service';
import {ListasService} from '../../core/services/listas/listas.service';
import {Router} from '@angular/router';
@Component({
  selector: 'app-films',
  imports: [
    NgClass
  ],
  templateUrl: './films.html',
  styleUrl: './films.scss',
})
export class Films {
    pelis : any;
    modoCrearLista = false
    confirmarLista = "Crear lista";

    constructor(private peliculasService : PeliculasService, public listasService : ListasService,
                        private router: Router) {
      this.pelis = this.peliculasService.getFilm();
    }

    // FILTRO - DISPLAY
    dropdownOpen = signal<string>('');

    toggleMenu(name: string) {
      if (this.dropdownOpen() === name) {
        this.dropdownOpen.set('');
      }else {
        this.dropdownOpen.set(name);
      }
    }
  // FILTRO - APLICAR
  // reminder Actualizar datos pelis y hacer un signal
  //  signals con valor all para q se muestren todas
  // Hacemos todos los filtros y luego hacemos un set
    filterYear = signal<string>('all')
    filterGenre = signal<string>('all')
    filterDuration = signal<string>('all')
    filterRating = signal<string>('all')

    filterByYear(year: string){
      this.filterYear.set(year);
      this.dropdownOpen.set('');
    }

    filterByGenre(genre: string){
      this.filterGenre.set(genre);
      this.dropdownOpen.set('');
    }

    filterByDuration(duration: string){
      this.filterDuration.set(duration);
      this.dropdownOpen.set('');
    }

  filterByRating(rating: string){
    this.filterRating.set(rating);
    this.dropdownOpen.set('');
  }

  resetFilter() {
      this.filterDuration.set('all')
      this.filterRating.set('all')
      this.filterGenre.set('all')
      this.filterYear.set('all')
      this.searchFilm.set('')
  }
//   FUNCIÓN PARA ENTRAR EN MODO CREAR LISTA
    toggleModoLista(){

      this.modoCrearLista = !this.modoCrearLista;
      if (this.modoCrearLista){
        this.confirmarLista = "Cancelar"
      }else {
        this.confirmarLista
        this.listasService.reset()
      }

    }

//   FUNCIÓN PARA QUE LEA CUANDO LE DOY CLICK A LA PELÍCULA
    clickPelicula(nombrePeli : string){
      if (this.modoCrearLista){
        this.listasService.toggle(nombrePeli)
        return
      }else {
        this.router.navigate(['/film-detail'])
      }
    }

// BUSCAR PELI
//   empieza vacia para que se vea todo y luego recibe el signal en lowercase
    searchFilm = signal<string>('');

    searchBar( buscado:string){
      this.searchFilm.set(buscado);
    }

}
