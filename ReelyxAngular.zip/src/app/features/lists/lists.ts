import { Component } from '@angular/core';

@Component({
  selector: 'app-lists',
  imports: [],
  templateUrl: './lists.html',
  styleUrl: './lists.scss',
})
export class Lists {

}
