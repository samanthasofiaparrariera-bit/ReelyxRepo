import { Component } from '@angular/core';

@Component({
  selector: 'app-pagina-principal',
  imports: [],
  templateUrl: './pagina-principal.html',
  styleUrl: './pagina-principal.scss',
})
export class PaginaPrincipal {

}
