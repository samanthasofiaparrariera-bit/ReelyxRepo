import {Component, inject, OnInit} from '@angular/core';
import {FormBuilder, FormGroup,Validators, ReactiveFormsModule} from '@angular/forms';
import {Router, RouterLink} from '@angular/router';
import {NgClass} from '@angular/common';
import {AuthCookieService} from '../../../../core/services/cookies/auth-cookie.service';
import {AuthService} from '../../../../core/services/usuarios/auth.service';

type DatosDeEnvio = { email?: string, password: string };
@Component({
  selector: 'app-login',
  imports: [
    RouterLink,  ReactiveFormsModule

  ],
  templateUrl: './login.html',
  styleUrl: './login.scss',
})



export class Login {

  formLogin: FormGroup;
  esCorreo: boolean = true;
  esLogin: boolean = true;

  constructor(private formBuilder: FormBuilder,
              private authService: AuthService,
              private authCookieService: AuthCookieService,
              private router: Router) {

    this.formLogin = this.formBuilder.group({
      "email": ["", [Validators.email, Validators.minLength(5)]],
      "password": ["", [Validators.required, Validators.minLength(5)]],
    })

  }

  iniciarSesion(){
    if (this.formLogin.invalid){
      alert("Formulario invalido")
      return;
    }

    const datosEnviar: DatosDeEnvio = {
      email: this.formLogin.value.email,
      password: this.formLogin.value.password
    }

    console.log("Iniciando sesión")

    this.authService.login(datosEnviar).subscribe({
      next: (response: any) => {
        this.authCookieService.set("reelyx_token", response.token);
        this.router.navigate(["/"]);
      },
      error: (error: any) => {
        alert("Error al iniciar sesión");
        console.log(error);
      }


    })

  }


}
