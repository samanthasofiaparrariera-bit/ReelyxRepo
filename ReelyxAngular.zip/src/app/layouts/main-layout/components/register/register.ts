import {Component, OnInit, output} from '@angular/core';
import {FormBuilder, FormGroup, ReactiveFormsModule, Validators} from "@angular/forms";
import {EmailValidator} from "../../../../core/validators/email.validator";
import {checkPassValidator} from '../../../../core/validators/password.validator';
import {AuthService} from "../../../../core/services/usuarios/auth.service";
import {NgClass} from '@angular/common';
import {EmailValidationError} from '@angular/forms/signals';
import {RouterLink} from '@angular/router';


@Component({
  selector: 'app-register',
  imports: [ReactiveFormsModule, RouterLink],
  templateUrl: './register.html',
  styleUrl: './register.scss',
})
export class Register implements OnInit {

  registerForm: FormGroup;

  cambiarForm = output<boolean>();
  fnToggleLoginHeader = output();
  // cambio el login con un register

  constructor(private formBuilder: FormBuilder,
              private authService: AuthService) {
    this.registerForm = this.formBuilder.group({
      "nombre": ["", [Validators.required]],
      "email": ["", [Validators.required, EmailValidator]],
      "password1": ["", [Validators.required, Validators.minLength(6), checkPassValidator]],
      "passwordValid": ["", [Validators.required]],
    })
  }

  ngOnInit(): void {
        throw new Error("Method not implemented.");
    }


  register() {
    if (this.registerForm.invalid) {
      alert("Formulario no valido...");
      return;
    }
    console.log("Registrando")

    this.authService.registro(this.registerForm.value).subscribe({
      next: (data:any) => {
        alert("Cuenta creada correctamente");
        this.registerForm.reset();
      },
      error: (e:any) => {
        console.log("Error al registrar", e)
      }
    })
  }
}
