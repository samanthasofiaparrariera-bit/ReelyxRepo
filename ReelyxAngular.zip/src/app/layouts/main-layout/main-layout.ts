import { Component } from '@angular/core';
import {RouterOutlet} from '@angular/router';
import {TopBar} from './components/top-bar/top-bar';
import {Footer} from './components/footer/footer';
@Component({
  selector: 'app-main-layout',
  imports: [ TopBar, Footer],
  styleUrl: './main-layout.scss',
  template: `
    <app-top-bar></app-top-bar>

    <app-footer></app-footer>
  `
})
export class MainLayout {

}
